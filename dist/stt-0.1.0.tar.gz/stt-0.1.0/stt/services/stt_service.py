from fastapi import HTTPException
from pydantic import ValidationError
from stt.models.session import User
from stt.services.chat_service import ChatService
from stt.services.store_service import StoreService
from stt.services.transcribe_service import TranscribeService


class SttService:
    async def save_audio(self, user: User, audio_content: bytes) -> str:
        user_id = user.id_
        session_id = user.session.id_

        with StoreService(user_id) as store_service:
            try:
                file_path = await store_service.save_audio(
                    session_id, user.session.audio.name, "audio/wave", audio_content
                )
                user.session.audio.file = file_path
                await store_service.update_metadata(user)

            except ValidationError as err:
                raise HTTPException(status_code=422, detail=str(err))

            except Exception as err:
                raise HTTPException(status_code=500, detail=str(err))

    async def transcribe(self, user_id: str, session_id: str) -> User:
        transcribe_service = TranscribeService(user_id)
        return await transcribe_service.transcribe_audio(session_id)

    async def output(self, user_id: str, session_id: str, output_type: str) -> any:
        chat_service = ChatService(user_id)
        return await chat_service.get_transcript_output(user_id, session_id, output_type)
