import json
from typing import Optional
from loguru import logger
from stt.models.session import User
from stt.services.azure_store_service import AzureStoreSevice
from datetime import datetime


class StoreService:
    user_id: str
    container_name: str = "users"
    storage_service: Optional[AzureStoreSevice]

    def __init__(self, user_id: str, container_name: str = None) -> None:
        self.user_id = user_id
        if container_name:
            self.container_name = container_name

    def __enter__(self):
        self.storage_service = AzureStoreSevice(self.user_id, self.container_name)
        return self

    async def __exit__(self, *args):
        await self.storage_service.close()

    async def save_audio(self, session_id: str, name: str, content_type: str, audio_content: bytes) -> str:
        blob_name = f"{self.user_id}/{session_id}/data/{name}"
        await self.storage_service.write_blob(blob_name, content=audio_content, content_type=content_type)
        return blob_name

    async def read_metadata(self, session_id: str) -> User:
        blob_name = f"{self.user_id}/{session_id}/meta/metadata.json"
        user_data_json = await self.storage_service.read_blob(blob_name=blob_name, binary=False)
        return User(**json.loads(user_data_json))

    async def update_metadata(self, user: User) -> User:
        blob_name = f"{user.id_}/{user.session.id_}/meta/metadata.json"
        content = user.model_dump_json()
        content_type = "text/plain"
        await self.storage_service.write_blob(blob_name=blob_name, content=content, content_type=content_type)
        return user

    async def get_transcript(self, file: str) -> bytes:
        logger.info(f"Reading {file} from Blob Storage")
        return await self.storage_service.read_blob(file, binary=False)

    async def save_output(self, session_id: str, output_type: str, content: str) -> str:
        blob_name = f"{self.user_id}/{session_id}/data/{output_type}.txt"
        await self.storage_service.write_blob(blob_name, content, content_type="text/plain")
        return blob_name

    async def get_output(self, file: str) -> bytes:
        logger.info(f"Reading {file} from Blob Storage")
        return await self.storage_service.read_blob(file, binary=False)

    async def get_audio(self, file_name: str) -> bytes:
        return await self.storage_service.read_blob(file_name, binary=True)

    async def save_transcript(self, session_id: str, content: str) -> str:
        blob_name = f"{self.user_id}/{session_id}/data/transcript_{datetime.now().strftime('%Y%m%d')}"
        await self.storage_service.write_blob(blob_name, content, "text/plain")
        return blob_name
