import os

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI
from stt.models.session import User
from stt.services.prompt_service import PromptService
from stt.services.store_service import StoreService


class ChatService:
    user_id: str

    def __init__(self, user_id: str) -> None:
        self.user_id = user_id

    def _get_llm(self) -> AzureChatOpenAI:
        """
        Get Large Language Model object connecting to GPTs in Azure
        """
        print(os.getenv("AZURE_GPT_DEPLOYMENT_NAME"))
        llm = AzureChatOpenAI(
            openai_api_version=os.getenv("OPENAI_API_VERSION"),
            azure_deployment=os.getenv("AZURE_GPT_DEPLOYMENT_NAME"),
            max_retries=1000,
        )
        return llm

    async def apply_transform(self, transcript: str, output_type: str, language: str = "nl") -> str:

        with PromptService(self.user_id) as prompt_service:
            system_prompt = await prompt_service.get_system_prompt()
            human_prompt = await prompt_service.get_human_prompts(output_type)

            prompt_template = ChatPromptTemplate.from_messages(
                [
                    ("system", system_prompt),
                    ("human", human_prompt),
                ]
            )
            chain = prompt_template | self._get_llm()
            answer_object = await chain.ainvoke(
                {
                    "language": language,
                    "transcript": transcript,
                }
            )
            return answer_object.content

    async def get_transcript_output(self, user_id: str, session_id: str, output_type: str) -> User:
        with StoreService(user_id) as store_service:
            user = await store_service.read_metadata(session_id)
            transcript = await store_service.get_transcript(user.session.transcript_corrected_file)
            output = await self.apply_transform(
                transcript,
                output_type,
                "Dutch"  # TODO: should not be hard coded
            )
            user.session.output_file = await store_service.save_output(session_id, output_type, output)
            return await store_service.update_metadata(user)
