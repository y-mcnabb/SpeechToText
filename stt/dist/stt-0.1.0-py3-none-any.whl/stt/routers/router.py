from fastapi import APIRouter, File, UploadFile, Depends
from stt.models.session import Session, User, AudioData
from stt.services.store_service import StoreService
from stt.services.stt_service import SttService
from loguru import logger
from typing import Generator
import os

# load_dotenv()
router = APIRouter()


def get_store_services() -> Generator[SttService, None, None]:
    ss = SttService()
    yield ss


@router.post("/upload-audio/{user_id}")
async def upload_audio(
    user_id: str, audio_file: UploadFile = File(...), service: SttService = Depends(get_store_services)
) -> User:
    session = Session(
        audio=AudioData(
            name=audio_file.filename,
            duration=10,
            size=audio_file.size,
            type=audio_file.content_type,
        )
    )
    user = User(id_=user_id, session=session)
    try:
        await service.save_audio(user, await audio_file.read())
    except Exception as ex:
        logger.info("Upload Audio Failed ", ex)
        return ex

    return user


@router.post("/transcribe/{user_id}/{session_id}", response_model=User)
async def transcribe(
    user_id: str, session_id: str, service: SttService = Depends(get_store_services)
):
    user = await service.transcribe(user_id, session_id)
    return user


@router.get("/transcript/{user_id}/{session_id}", response_model=str)
async def get_transcript(user_id: str, session_id: str):
    with StoreService(user_id) as store_service:
        user: User = await store_service.read_metadata(session_id)
        return await store_service.get_transcript(user.session.transcript_corrected_file)


@router.post("/output/{user_id}/{session_id}/{output_type}", response_model=User)
async def generate_output(
    user_id: str, session_id: str, output_type: str, service: SttService = Depends(get_store_services)
):
    return await service.output(user_id, session_id, output_type)


@router.get("/output/{user_id}/{session_id}/", response_model=str)
async def get_output(
    user_id: str, session_id: str
):
    with StoreService(user_id) as store_service:
        user: User = await store_service.read_metadata(session_id)
        return await store_service.get_output(user.session.output_file)


@router.get("/allenv")
async def get_allenv():
    return os.environ.items()
