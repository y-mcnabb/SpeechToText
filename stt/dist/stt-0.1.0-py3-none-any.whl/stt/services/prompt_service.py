import os
import json
from typing import Optional
from stt.services.azure_store_service import AzureStoreSevice


class PromptService:
    user_id: str
    container_name: str = "prompts"
    storage_service: Optional[AzureStoreSevice]

    def __init__(self, user_id: str, container_name: str = None) -> None:
        self.user_id = user_id
        if container_name:
            self.container_name = container_name

    def __enter__(self):
        self.storage_service = AzureStoreSevice(self.user_id, self.container_name)
        return self

    async def __exit__(self, *args):
        await self.storage_service.close()

    async def get_human_prompts(self, prompt_type: str) -> str:
        human_prompts = json.loads(await self.storage_service.read_blob("human_prompts.json", binary=False))
        return human_prompts[prompt_type]

    async def get_system_prompt(self) -> str:
        return await self.storage_service.read_blob("system_prompt.txt", binary=False)

    def load_system_content(self, path: str, prompt_type: str) -> str:
        return self._read_prompt(path, prompt_type, "system_content.txt")

    def load_user_content(self, path: str, prompt_type: str) -> str:
        return self._read_prompt(path, prompt_type, "user_content.txt")

    def _read_prompt(path: str, prompt_type: str, file_name: str):
        with open(os.path.join(path, prompt_type, file_name), "r") as f:
            return f.read()
