import os
from aiohttp import ClientSession, FormData
from loguru import logger
from stt.models.session import User
from stt.services.chat_service import ChatService
from stt.services.store_service import StoreService
from stt.utils.audio_tools import compress_audio_file


class TranscribeService:
    user_id: str

    def __init__(self, user_id: str) -> None:
        self.user_id = user_id

    async def _call_azure_openai_transcribe(
        self,
        session: ClientSession,
        audio_data: bytes,
        audio_name: str,
        language: str = "nl",
    ) -> bytes:
        url = (
            f"{os.getenv('AZURE_OPENAI_ENDPOINT')}/openai/deployments/"
            + f"{os.getenv('AZURE_SPEECH_DEPLOYMENT_NAME')}/audio/"
            + f"transcriptions?api-version={os.getenv('OPENAI_API_VERSION')}"
        )
        headers = {"api-key": os.getenv("AZURE_OPENAI_API_KEY")}

        # Prepare the audio file in FormData
        data = FormData()
        data.add_field("file", audio_data, filename=audio_name, content_type="audio/wav")

        # Set the language parameter if necessary
        params = {"language": language}

        try:
            async with session.post(url, headers=headers, data=data, params=params) as response:
                response.raise_for_status()
                transcript_data = await response.json()
                transcript = transcript_data["text"].encode("utf-8")
                return transcript

        except Exception as err:
            logger.error("Call to Azure OpenAI failed", err)

    async def transcribe_audio(self, session_id) -> User:
        chat_service = ChatService(self.user_id)
        with StoreService(self.user_id) as store_service:
            user = await store_service.read_metadata(session_id)
            audio_data = compress_audio_file(await store_service.get_audio(user.session.audio.file))

            # Initialise `aiohttp.ClientSession` for asynchronous AzureOpenAI Whisper transcribe
            async with ClientSession() as session:
                transcript = await self._call_azure_openai_transcribe(
                    session, audio_data, user.session.audio.name
                )

            user.session.transcript_file = await store_service.save_transcript(user.session.id_, transcript)
            corrected_transcript = await chat_service.apply_transform(transcript, output_type="correction")
            user.session.transcript_corrected_file = await store_service.save_transcript(
                session_id, corrected_transcript
            )
            return await store_service.update_metadata(user)
